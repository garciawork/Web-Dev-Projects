var faker = require("faker");

for(var i = 0; i < 100; i++){
   console.log(faker.date.between());
}

function echo(str, num){
    for(var i = 1; i <= num; i++){
        console.log(str);
    }
}

echo("Echo!!!", 10) //should print "Echo!!!" 10 times
echo("Tater Tots", 3) //should print "Tater Tots" 3 times

//copied straight from Colt's file, still won't work...
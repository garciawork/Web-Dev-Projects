var express = require("express");
var app = express();

app.use(express.static("public"));
app.set("view engine", "ejs");

app.get("/", function(req, res){
    res.render("home");
});

app.get("/fallinlovewith/:thing", function(req, res){
    var thing = req.params.thing;
    res.render("love", {thingVar: thing});

});
//dafaq won't this work...?
// app.get("/fallinlovewith/:thing", function(res, req){
//     var thing = req.params.thing;
    
app.get("/posts", function(req, res) {
    var posts = [
        {title: "Post 1", author: "Suzy"},
        {title: "Post 2", author: "Ben"},
        {title: "Post 3", author: "Matt"},
        {title: "Post 4", author: "Jerry"}
        ]
        res.render("posts", {posts: posts});
})


app.listen(process.env.PORT, process.env.IP, function (){
    console.log("server up homie!")
})
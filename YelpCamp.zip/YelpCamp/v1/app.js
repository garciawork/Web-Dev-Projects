var express = require("express");
var app = express();
var bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs")

var campgrounds = [
            {name: "Salmon Creek", image: "https://farm8.staticflickr.com/7044/6926054941_bff36e68de.jpg"},
            {name: "Idaho City", image: "https://farm7.staticflickr.com/6086/6085126222_98e7d5efea.jpg"},
            {name: "McCall", image: "https://farm5.staticflickr.com/4423/37232133702_342e447ccb.jpg"},
            {name: "Prairie City", image: "https://farm9.staticflickr.com/8037/8050540841_449bf00ed0.jpg"},
        ];  

app.get("/", function(req, res){
    res.render("landing");
});

app.get("/campgrounds", function(req, res){
        res.render("campgrounds", {campgrounds: campgrounds});
});

//REST... apparently
app.post("/campgrounds", function(req, res){
    //get data from form and add to caompgrounds array
    var name = req.body.name;
    var image = req.body.image;
    var newCampground = {name: name, image: image}
    campgrounds.push(newCampground);
    //redirect back to campgrounds page
    res.redirect("/campgrounds");
});

app.get("/campgrounds/new", function(req, res){
    res.render("new.ejs");
});


app.listen(process.env.PORT, process.env.IP, function(){
    console.log("The YelpCamp App has started");
});


//***************************************
//stopped coding at 8:15ish
//***************************************
var express = require("express");
var app = express();

app.get("/", function(req, res){
    res.send("Hi there, welcome to my assignment!")
});

app.get("/speak/:animalName", function(req, res){
    var sounds = {
        pig: "oink",
        dog: "woof",
        cat: "meow",
        cow: "moo",
        sheep: "baah",
    }
    var animalName = req.params.animalName.toLowerCase;
    var sound = sounds[animalName];
    res.send("The " + animalName + " says " + sound)
    // res.send("The " + animalName +" says " + "")
});

app.get("/repeat/:message/:times", function(req, res) {
   var message = req.params.message;
   var times = Number(req.params.times); 
   var result = ""; 
   for(var i = 0; i < times; i++){
        result += message + " ";
   }
   res.send(result);
});

//trying to figure out the function and loop for this...
// app.get("/repeat/:talk/:num", function(req, res) {
//     var talk = req.params.talk;
//     var num = req.params.num;
//     var number = Number(num);
//     for(var i = 0; i < number; i++) {
//         res.send(talk * number)
//     };
//       console.log(Number(num));
// });

app.get("*", function(req, res) {
    res.send("Sorry, no page found... What are you doing with your life?")
});


app.listen(process.env.PORT, process.env.IP, function(){
    console.log("Server has started")
}); 